---
name: solidworks-plus-plus
description: "SolidWorks++（非官方）——SolidWorks 2023 零件建模、装配与工程图技能。给出三视图、剖视图、轴测图/直观图或照片时建立可编辑三维零件；给出已有 SLDPRT/SLDASM 时生成 GB 第一角三视图、PDF 和审查报告。支持示意模式（定性、不抠尺寸）与精确模式（按图、可交付），并附装配/运动、有限元验证判据与管道布线人工流程。内置确定性脚本、参数表、验证门禁和失败分支。"
---

# SolidWorks++ 建模与出图

> **SolidWorks++ 是建立在 SolidWorks API 之上的工程库与工作流层**：不是新的 CAD 内核，也不是 SolidWorks 的修改版；输出仍是原生 SLDPRT/SLDASM，任何 SolidWorks 都能打开。
> SolidWorks 是 Dassault Systèmes 的注册商标；本项目与其无隶属或背书关系。

本技能只有一个执行权威：**先判定模式与输入类型，再按固定路线调用脚本**。
不要临场发明 API、不要跳过验证、不要把“保存成功”当成“建模成功”。

## 0. 环境与路径约定（实测基线）

| 项 | 值 |
|---|---|
| SolidWorks | 2023 SP0.1 实测（其他版本按 `capabilities.yaml` 的未验证项处理），ProgID `SldWorks.Application` |
| Python | 3.9+，依赖 pywin32、comtypes、Pillow、PyMuPDF；开发机用 `py -3.12` 启动器，目标机按本机解释器调用 |
| 技能目录 | 本 SKILL.md 所在目录，下文记作 `<skill>`；用户工作目录记作 `<workdir>`。文档里的路径命令把这两个占位符替换成实际路径即可 |
| 图幅模板 | 脚本自动搜索 `ProgramData\SOLIDWORKS\SOLIDWORKS *\templates` 与 `Program Files` 语言目录；找不到时按报错手动指定 |

自检：

```bash
py -3.12 "<skill>\scripts\sw_preflight.py"
```

`capabilities.yaml` 是能力等级的唯一真源；`pilot` 能力必须做结果审查，`reference_only` / `not_implemented` 不得当作无人值守交付。

## 0.5 质量分层（弱模型保底，强模型加高）

同一个 skill 服务不同能力的模型，**不靠删知识来降门槛**：

| 层级 | 适用 | 必读 | 交付线 |
|---|---|---|---|
| **L1 保底** | 能力较弱/上下文受限 | 本文件 + 路线文档 + `quick-snippets.md` + 命中的配方 | 第 5 节门禁全部通过；几何、实体、孔、图纸不得错 |
| **L2 专业** | 中等及以上模型 | L1 + `part-modeling.md`、`feature-strategy.md`、`expert-thinking.md`、`drawing-standards.md`、`standard-parts.md`、`pitfalls.md` | 加：特征顺序与选型、公差/配合、表面粗糙度、标准件、GB 视图规范 |
| **L3 专家** | 强模型/复杂件 | 全部 references + `case-library.md` + 题库案例 | 加：复杂曲面、装配、运动、工艺性审查 |

规则：

- **L1 是地板，不是天花板。** 弱模型照 L1 做也必须能交付合格件；强模型在 L1 通过后继续 L2/L3，不得被 L1 的简化步骤限制。
- **门禁只拦错误交付，不拦更好的方案。** 强模型可以用配方之外的建模顺序，只要第 5 节证据齐全。
- **不得为了省 token 删除或跳过 L2/L3 的检查项**；上下文不够时先完成 L1，再在下一轮补 L2/L3。

## 1. 开工协议（每次任务先做）

1. 判定输入类型：`三视图/工程图`、`轴测图/照片`、`已有模型`、`文字需求`。
2. 确认对象：做什么、长什么样、几个零件、用在哪儿——不清楚就先问，不猜（见 `references/modes-and-questions.md` 第 1 节第 0 步）。
3. 判定模式（模式本身只问一次；**提问贯穿全程**，决策门禁见 `references/modes-and-questions.md` §2.5）：
   - **A 示意模式**：定性看形状，不抠尺寸——不问具体数值，只问对象/结构/拓扑。
   - **B 精确模式**：按图施工，尺寸可追溯，可交付——图纸/描述缺失的关键尺寸必须逐项提问（grill-me 多轮，贯穿全程）。
   - 用户没明说模式（需求模糊）→ 用 `references/modes-and-questions.md` §1.1 六段式模板把两种模式的提问范围、交付物、选错后果讲透再问，**不许一句带过**；选 B 时向用户说明“后续缺失的每个关键尺寸都会停下来问你”。
   - 判据表和提问模板见 `references/modes-and-questions.md`。
4. 关键信息不确定 → 先问再建：一次最多 4 问，可多轮；只有用户说“你定/随便”或确认“这项确实确定不了”后才按推荐值建模并标记来源。**不许猜一个值先建着。** 每条提问按 §2.6 自检：带依据、带选项后果、带推荐。
5. 生成任务卡（模式、交付物、包络、实体数、特征组、假设清单、未决问题）。
6. 按路线执行；每个关键步骤后检查返回值。**每进入新阶段前（装配/出图/导出等）重扫任务卡未决问题（G1）；执行中发现重大分支——影响多个后续步骤或返工成本高——立即停下提问（G2），不许攒到交付。**
7. 交付前通过验证门禁，展示预览和假设清单。

🔴 **CHECKPOINT 1**：说明对象理解 + 模式与交付物；模式是问出来的（§1.1）要重申两种模式差异与后果（A 不问数值只问结构；B 缺失尺寸逐项提问）。
🔴 **CHECKPOINT 2**：存在任何未确定关键项（含模式 A 的对象/结构）时，先提问、展示任务卡，等用户回答或授权。
🔴 **阶段门禁（G1/G2）**：进入新阶段前重扫任务卡 `OpenQuestions`；执行中发现重大分支立即停下问，不许攒到交付。
🔴 **CHECKPOINT 3**：交付时展示包围盒、实体数、预览、尺寸证据和文件路径。

## 2. 路线选择

| 用户意图 | 路线 | 主文档 |
|---|---|---|
| 三视图 / 工程图 / 剖视图 + 直观图 → 三维模型 | **A：图 → 模型** | `references/drawing-to-part.md` |
| 已有 SLDPRT/SLDASM → 三视图 / 工程图 / PDF | **B：模型 → 图** | `references/part-to-drawing.md` |
| 照片 / 截图 → 示意模型 | A + 图片估读 | `references/image-to-part.md` |
| 只改尺寸、改特征、加孔 | 参数修改 / 局部重建 | `references/part-modeling.md`、`references/quick-snippets.md` |
| 定特征顺序、选拉伸终止条件、圆角/抽壳/阵列选型、修特征树 | 特征策略 | `references/feature-strategy.md` |
| 不背配方：读图分解、判断选型、自检习惯的专家思维 | 建模思维 | `references/expert-thinking.md` |
| 装配、配合、运动 | 装配子流程 | `references/assembly.md`、`references/motion-study.md` |
| 螺纹孔、沉孔、沉头孔、槽 | 孔特征子流程 | `references/complex-hole-features.md` |
| 螺栓、键、轴承、齿轮、弹簧等标准件 | 标准件路线 | `references/standard-parts.md` |
| 出图公差/粗糙度/技术要求 | GB 制图规范 | `references/drawing-standards.md` |
| 自由曲面件、模具型腔、导入无特征史曲面 | 曲面路线（先判能否降级为实体） | `references/surfacing.md` |
| 管道 / 管筒 / 电气布线、Routing 规划与验收 | 布线路线（**本技能不自动布线**） | `references/piping.md` |
| 有限元选型、网格、边界条件、结果判据 | 验证方法（求解器无关） | `references/verification.md` |
| 多圆角/倒角 CNC 件 | 子技能 | `subskills/solidworks-fillet-chamfer-cnc/SKILL.md` |
| 螺纹孔规格与装饰螺纹 | 子技能 | `subskills/solidworks-threaded-holes/SKILL.md` |

**上下文受限时的最低必读三份**：本文件 + 对应路线文档 + `references/quick-snippets.md`。
这是 L1 保底包，不是能力上限；完成 L1 门禁后，按第 0.5 节继续读 L2/L3 文档，不要通读无关 references。

## 3. 路线 A：图 → 模型（固定顺序）

1. **清点输入**：给每张图编号并标注视图类型、尺寸清晰度。
2. **判定投影**：中国图纸默认第一角（俯视图在主视图下方，左视图在右方）。
3. **形体分析**：分线框 → 对投影 → 定体素 → 定组合 → 定基准。
4. **填三张表**：总体尺寸、特征尺寸、定位尺寸；每个值标来源
   （`explicit/derived/standard/user_confirmed/user_delegated/assumed/estimated`）。
   关键尺寸缺来源 → **先问，不编**（见 `references/modes-and-questions.md` 2.1）。
5. **建任务卡**：坐标系固定 X=长、Y=高、Z=深；把信息最多的视图
   画在 Front Plane（XY）。**若图纸主视图是侧剖面**（L 形支架、台阶轴、盘类剖面），
   就把侧剖面画在 Front Plane，平面轮廓放 Top/Right；出图后必须在交付说明里
   写清生成图的 Front/Top 分别是哪个视图，不能让用户按错的主视图加工。
6. **先匹配零件族配方**（`references/recipes/`），**套用前先过一遍“判断先行”**（配方 README：结构对不对得上、尺寸链齐不齐、主视图角色、终止条件选型、顺序理由），再按七步建模：
   基础体 → 主体 → 凸台/筋 → 孔槽 → 阵列/镜像 → 圆角/倒角 → 收尾。
   配方已给出固定顺序和代码骨架，不要临场重排；**但判断与配方冲突时以判断为准**，并在交付说明记录替换原因。配方未覆盖时，按
   `references/feature-strategy.md` 的选型、终止条件与顺序规则执行
   （尤其：先圆角后抽壳、孔排在抽壳后、装饰圆角最后）。
7. **逐项验证**：包围盒、实体数、孔证据、四视图预览。
8. **交付**：`.SLDPRT` + 参数表 + 预览 + 审查报告；模式 B 追加 `.STEP`。

硬规则：

- 所有长度输入用毫米，调用 `mm()`；API 内部单位是米。
- 草图必须闭合；每个特征调用后检查返回值是否为 `None`。
- 先加后减；圆角/倒角最后做。
- 特征命名写清用途和关键尺寸，如 `02_BORE_D36`；用封装的 `name=` 参数
  （`extrude_boss/extrude_cut/create_*_hole` 都支持），不要另写改名代码。
- 方向不确定时先做一个特征，回读 `GetPartBox(True)` 再继续。
- 不要用屏幕坐标选面/选边；用几何条件或特征名。

最小脚本骨架见 `references/drawing-to-part.md` 第 6 节；可复制 API 见 `references/quick-snippets.md`。

## 4. 路线 B：模型 → 三视图

一条命令：

```bash
py -3.12 "<skill>\scripts\sw_three_view.py" \
  --part "<workdir>\part.SLDPRT" --out-dir "<workdir>\drawing" \
  --paper A3 --projection first --dims --iso
```

输出：`.SLDDRW`、`.pdf`、`_drawing_preview.png`、`_drawing_report.json`。

必须检查：

1. `report["status"]` 为 `pass`，视图数 ≥ 3。
2. `report["sheet_setup"]["sheet_size_verified"]` 为 `true`，
   且 `actual_size_m` 与所选图幅一致（A3 = 0.420×0.297）。**不要只看 `configured: true`**。
3. `dimension_count > 0`；为 0 时回模型给草图/孔补尺寸（`auto_dimension_sketch`），
   不要说“已自动标注”。API 直接画线不会产生尺寸。
4. 预览 PNG 非空白，且目视确认：第一角布局（俯视图在下、左视图在右）、
   长对正/高平齐/宽相等、尺寸不重叠、不侵入标题栏。
5. 保留 `.SLDDRW`，不要只交 PDF。

详细验收与失败分支见 `references/part-to-drawing.md`。

## 5. 验证门禁（所有任务）

| 门禁 | 通过标准 | 证据 |
|---|---|---|
| 文件 | `.SLDPRT` 存在且能重新打开 | 文件大小 > 0 |
| 几何 | 包围盒与总体尺寸一致 | B：≤ max(0.1 mm, 0.2%)；A：≤ 5% |
| 体积 | 与参数表手算体积差 ≤ 0.1% | `collect_geometry_measurements()["volume_mm3"]` |
| 实体 | 实体数等于任务卡 `BodyCount` | `GetBodies2(0, False)` |
| 特征 | 关键特征存在、无重建错误 | `ForceRebuild3(False)` + 特征树 |
| 孔 | 孔径/孔位与图纸一致 | `collect_geometry_measurements()` |
| 视觉 | 四视图预览方向、比例、特征正确 | `run_review()` 导出的 BMP |
| 图纸 | 视图数、尺寸数、布局、PDF | `_drawing_report.json` + PDF 首屏 |

```python
report, path = run_review(part, r"<workdir>\review", basename="part",
                          expected_outputs=[r"<workdir>\part.SLDPRT"])
print(report["evaluation"]["status"], report["evaluation"]["issues"])
```

`evaluation.status` 不是 `pass` 时禁止宣布完成；先修复并重新生成。

改完技能后至少跑 `test-prompts.json` 里的 6 个黄金用例：
`d2p_b_link_001`（包围盒必须等于 67.37778×38.107013×10.0）、
`d2p_b_plate_holes`（包围盒 120×80×12，6 个圆柱面，体积 99794.337 mm³）、
`d2p_b_flange_cbore`（包围盒 32×120×120，6 个 φ9+φ15 复合孔，体积 143401.138 mm³）、
`m2d_a3_first_angle`（A3 回读 0.420×0.297、视图 ≥3、尺寸 >0）、
`d2p_b_missing_dims`（必须先问再建，可多轮）、
`d2p_a_ambiguous_object`（对象不清时必须先问清对象和拓扑）。

**体积是最便宜的全量自检**：孔漏切、缺口没开、凸台高度错，包围盒都看不出来，
体积会立刻露馅。建模脚本里按参数表手算期望体积并断言，差 > 0.1% 就停下来查。

## 6. 失败分支

| 触发条件 | 一线修复 | 仍失败兜底 |
|---|---|---|
| 连接失败 / RPC 不可用 | 确认 SolidWorks 已启动、无残留进程；用 `--visible` 重试一次 | 重启 SolidWorks 后再连一次；仍失败就停止并告知用户，不要连续重试 |
| 草图未闭合 / 拉伸返回 `None` | 检查轮廓自交、漏边；先用最简单矩形验证 | 重画闭合轮廓；导出草图截图目视检查；仍失败则停下问用户，不要继续叠加特征 |
| 切除方向反了 | 按材料所在侧翻转 `direction`，回读包围盒 | 在加工面建偏置面，只做一个试验孔；确认无误再批量 |
| 孔位整体偏移 | 检查 Top Plane 纵轴符号（`v = −Z`） | 改中心对称布局，或把孔系移到 Front Plane；回读 `position_mm` 逐项比对 |
| 视图创建返回 `None` | 用 `GetModelViewNames()` 读本机名（中文版 `*前视` 等），重试一次 | 逐视图单独创建并记录 `failures`；缺视图不得交付，停下来问用户 |
| 图纸空白 / 视图在纸外 | 查 `sheet_size_verified` 与 `actual_size_m`；SW2023 A3 码是 8，不是 6 | 用同码重设图幅并重排布局；仍空白就打开 `.SLDDRW` 人工检查模板 |
| 尺寸数为 0 | 回模型对每个草图调用 `auto_dimension_sketch()`，重新出图 | 检查特征树有无 DisplayDimension；仍为 0 就停下说明原因（如导入实体无草图尺寸），不得用“模型无尺寸”绕过门禁交付，也不得声称已自动标注 |
| 预览空白 | 检查 PDF 是否落盘（SaveAs 可能返回 False 但文件已写入） | 重新导出并渲染；仍空白就打开 `.SLDDRW` 截图，不要交付空白预览 |
| 圆角失败 | 跳过圆角，保留直边，交付说明标注“外观圆角未应用” | 改用草图圆角/圆角矩形；不要为圆角重做主体超过一次 |

## 7. 黑名单（出现即返工）

- ❌ 不判定模式就直接建模。
- ❌ 需求模糊时模式判定一句带过，不说明两种模式的提问范围与后果。
- ❌ 把虚线当外轮廓，或把轴测图斜线当真实角度。
- ❌ 用屏幕坐标、`SelectByID2("Edge1")` 选边选面。
- ❌ 猜测未封装的 COM 方法签名和枚举值。
- ❌ 草图未闭合就拉伸，或特征返回 `None` 还继续叠加。
- ❌ 圆角在主体切除之前做。
- ❌ 只保存不审查，或只看“无报错”不看预览图。
- ❌ 用第三角布局交付国内加工图纸。
- ❌ 尺寸数为 0 却声称“已自动标注”。
- ❌ 覆盖上一轮交付文件；新产物用新文件名或新版本目录。
- ❌ 隐瞒 `assumed`/`estimated` 参数的来源。
- ❌ 关键信息不确定就瞎猜尺寸/结构开始建模（先问；仅用户确认“确定不了”或授权后才可编）。
- ❌ 推荐值未经用户确认就当作答案使用。
- ❌ 不判断实际结构就背配方生搬硬套特征顺序（配方是起点，判断后按 `feature-strategy.md` 调整）。
- ❌ 只在开工问一次，过程中发现新歧义不提问、攒到交付再补“假设”。
- ❌ 重大分支（影响多个后续步骤/返工成本高）自己拍板，不提问。

## 8. 参考文件与子技能

| 文件 | 用途 |
|---|---|
| `references/modes-and-questions.md` | 模式判定、提问规则、决策门禁（G0/G1/G2）、任务卡、检查点 |
| `references/drawing-to-part.md` | 图 → 模型完整流程、尺寸表、验证 |
| `references/part-to-drawing.md` | 模型 → 三视图、验收、失败分支 |
| `references/quick-snippets.md` | 可复制代码：草图、拉伸、孔、阵列、审查、出图 |
| `references/pitfalls.md` | 单位、选择、坐标系、COM 兼容等高频坑 |
| `references/part-modeling.md` | 特征与草图细节 |
| `references/feature-strategy.md` | 设计意图、草图规划、特征顺序、终止条件、圆角/抽壳/拔模、阵列选型、修复与配置（含 API 缺口） |
| `references/expert-thinking.md` | 专家建模思维（知识库提炼）：读图分解、判断选型、自检习惯、该问用户的时刻 |
| `references/drawing-standards.md` | GB 视图/尺寸/公差/粗糙度/技术要求与出图自检 |
| `references/standard-parts.md` | 螺栓/键/轴承/齿轮/弹簧/链轮/销的建模策略与速查表 |
| `references/surfacing.md` | 曲面适用边界、补洞/加厚/修复选型、失败处理（含“未封装”边界） |
| `references/complex-hole-features.md` | 盲孔/沉孔/沉头/槽与孔位验收 |
| `references/assembly.md`、`motion-study.md` | 装配、配合、运动算例 |
| `references/verification.md` | 有限元选型、边界条件、网格、后处理判据与失败分支（Simulation/Motion 知识） |
| `references/piping.md` | 管道与布线：线路组织、配件拓扑、折弯/直段、自动步路、验收、BOM（不含 Routing API） |
| `references/review.md` | 自审查报告字段与门禁 |
| `references/troubleshooting.md` | COM 报错与兼容问题 |
| `references/dataset-patterns.md` | 题库挖掘出的建模顺序与尺寸模式（训练产物） |
| `references/recipes/` | 按零件族拆分的固定建模配方（训练产物） |
| `references/case-library.md` | 已实测/题库模式案例：参数表、特征顺序、验证结果 |
| `test-prompts.json` | 10 个可重复验收用例（6 个黄金）：黄金包围盒、法兰沉孔、图幅、尺寸数、该问不该问 |
| `capabilities.yaml` | 能力等级唯一真源（含 SW2023 实测限制） |
| `golden-workflows.yaml` | 关键工作流的必需输入与产物 |

子技能（按需读取，不要默认全读）：

- `subskills/solidworks-fillet-chamfer-cnc/SKILL.md`：多圆角/倒角 CNC 件。
- `subskills/solidworks-threaded-holes/SKILL.md`：螺纹孔、攻丝底孔、装饰螺纹。
- `subskills/solidworks-vibecad/SKILL.md`：自然语言 → 结构化设计计划。
- `subskills/autocad-automation/SKILL.md`：DWG/DXF 二维图纸（需 AutoCAD；未安装时仅走无头路线）。
